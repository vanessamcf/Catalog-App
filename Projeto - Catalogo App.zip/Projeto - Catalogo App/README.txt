Requirements Softwares

    Python 2
    SQLAlchemy 1.2.18
    Flask 1.0.2
    Flask-HTTPAuth 3.2.4
    httplib2 0.12.1
    oauth2client 4.1.3
    Werkzeug 0.14.1

To run this final project

    run db_setup.py to create the database
    run basic.py to populate the database
    run application.py and navigate to localhost:8000 in your browser

